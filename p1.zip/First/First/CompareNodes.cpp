#include "CompareNodes.h"



CompareNodes::CompareNodes()
{
}


CompareNodes::~CompareNodes()
{
}
